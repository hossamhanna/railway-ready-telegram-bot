# Railway-ready Telegram Bot

## خطوات النشر على Railway

1. أنشئ مستودع GitHub وادفع (push) كل الملفات.
2. سجّل/دخول إلى https://railway.app
   - أنشئ مشروع جديد `New Project` → `Deploy from GitHub` → اختر المستودع.
3. في صفحة المشروع > Settings > Variables زيد المتغيرات:
   - `BOT_TOKEN` = التوكن من BotFather
   - `DATABASE_URL` = (اختياري) رابط PostgreSQL لو ضفت Add-Plugin → PostgreSQL
   - `ADMIN_IDS` = أرقام المشرفين مفصولة بفاصلة
4. إذا استعملت Docker لا تحتاج Procfile، Railway يبني الصورة. وإلا Procfile موجود ويشغل `python bot.py`.
5. اضغط Deploy وانتظر الـ build logs. إذا نجح، البوت يشتغل 24/24.

## التشغيل محلياً
```bash
python -m venv .venv
source .venv/bin/activate  # أو .venv\Scripts\activate على Windows
pip install -r requirements.txt
export BOT_TOKEN="<token>"
export ADMIN_IDS="12345"
export DATABASE_URL="postgres://..."  # اختياري
python bot.py
---

### 6. ملف `bot.py`
```python
import os
import logging
import asyncio
import psycopg2
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_IDS = set([s.strip() for s in os.getenv("ADMIN_IDS", "").split(",") if s.strip()])
DATABASE_URL = os.getenv("DATABASE_URL")

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def connect_db():
    if not DATABASE_URL:
        return None
    conn = psycopg2.connect(DATABASE_URL, sslmode='require')
    return conn

def init_db(conn):
    with conn.cursor() as cur:
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS visits (
                id SERIAL PRIMARY KEY,
                user_id BIGINT NOT NULL,
                username TEXT,
                first_name TEXT,
                ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """
        )
        conn.commit()

def insert_visit(conn, user):
    with conn.cursor() as cur:
        cur.execute(
            "INSERT INTO visits (user_id, username, first_name) VALUES (%s, %s, %s)",
            (user.id, user.username, user.first_name)
        )
        conn.commit()

def count_visits(conn):
    with conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM visits;")
        return cur.fetchone()[0]

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = f"مرحبا {user.first_name}! هذا بوت شغّال على Railway. جرب /status إذا كنت ADMIN."
    await update.message.reply_text(text)

    conn = context.application.bot_data.get("conn")
    if conn:
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, insert_visit, conn, user)

async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if ADMIN_IDS and str(user.id) not in ADMIN_IDS:
        await update.message.reply_text("ما عندكش صلاحية باش تعمل هذا.")
        return

    conn = context.application.bot_data.get("conn")
    visits = "(DB غير مكوّن)"
    if conn:
        loop = asyncio.get_running_loop()
        visits = await loop.run_in_executor(None, count_visits, conn)

    await update.message.reply_text(f"البوت شغّال ✅\\nالزيارات المسجلة: {visits}")

def main():
    if not BOT_TOKEN:
        logger.error("لازم تحط BOT_TOKEN في متغيرات البيئة")
        return

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    if DATABASE_URL:
        try:
            conn = connect_db()
            init_db(conn)
            app.bot_data["conn"] = conn
            logger.info("DB متّصلة وتهيئة الجداول تمت.")
        except Exception as e:
            logger.exception("فشل في ربط الـ DB — الاستمرار بدون DB")

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("status", status))

    logger.info("Starting bot (polling)...")
    app.run_polling()

if __name__ == "__main__":
    main()